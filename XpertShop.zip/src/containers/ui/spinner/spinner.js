import React from "react";
import "./spinner.css";

const spinner = () => <div className="loader">Loading...</div>;
export default spinner;
