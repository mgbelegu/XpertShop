# Xpert Systems eShop

This project was created using React JS.

## Install

Run:

### `npm install` 
and then
### `npm start` 
